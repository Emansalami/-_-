class daraamd():
    
    def __init__(self, hours, rate):
        self.hours = hours
        self.rate = rate
x = income(int(input(" enter hours : ")), 12)
if x.hours > 45 :
    result = (x.hours - 45) * (12) + 400
    print("your income is : " , result )     
else :
    print ("income will be : " , x.hours * x.rate)
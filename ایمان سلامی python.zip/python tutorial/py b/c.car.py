class car:
 def _init_(self,car brand,car model,color of the car,made year,c horse power):
 	self.car brand = car brand
	self.car model = car model
	self.color of the car = color of the car
	self.made year = made year
	self.c horse power = c horse power
 def car(self):
	print(self.car brand, self.car model, self.color of the car, self.made year, self c horse power)
	if self.carhorse power < 500:
 	 print("this car is slow as fuck man")
	else:
 	 print("now we can gap anyone on road")


j1 =car("audi","rs7","black",2023,591)
j2 =car("bmw","m5 cs","black",2023,627)
print(j2.car())
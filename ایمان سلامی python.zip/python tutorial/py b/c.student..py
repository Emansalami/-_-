class Student:
  def __init__(self,first name,last name ,  age , gender  , city):
    self.first name = first name
    self.last name = last name
    self.age = age
    self.gender = gender
    self.city = city

j1 = Person("carl","janson" , "29" , "Male" , "los santos")

print(j1.name)
print(j1.age)
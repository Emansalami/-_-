#type
hesab = 124 + 5342
print (hesab)
# type with words :
x = 'thanks' + ' God'
print (x)

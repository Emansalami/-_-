print(float(919) + 640)
a = 234
type(a)
Fl1 = float(a)
print(Fl1)
type(Fl1)

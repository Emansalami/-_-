x = 13
print('Hello')

def print_my_statics():
    print("I'm a Programmer, .")
    print('I try too hard to be more succese in life ! :) .')

print_my_statics()
x = x + 7
print(x)

# Moghaiese adad ha
# agar mosavi bashad
N1 = int(input())
if N1 == 5 : 
    print('Equals 5')
#agar adad az 4 bozorgar bashad
elif N1 > 4 : 
   print('Greater than 4')
# agar adad bozorgtar ia mosavi bashad
elif N1 >= 5 :
    print('Greater than or Equals 5')
elif N1 < 6 : print('Less than 6') 
elif N1 <= 5 :
    print('Less than or Equals 5')
elif N1 != 6 :
    print('Not equal 6')

'Expression tutorial Addition :'
a= 6
a= a + 2
print (a)
'Expression tutorial Multiplication :'
b= 6
b= b * 2
print (b)
'Expression tutorial Division :'
c= 12
c= c / 2
print (c)
'Expression tutorial Remainder :'
d = 13
d= d % 2
print (d)

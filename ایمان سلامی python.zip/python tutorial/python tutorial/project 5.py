def eman():
    print('hi')
    print('eman !')
 
eman()
print('Next')
eman()

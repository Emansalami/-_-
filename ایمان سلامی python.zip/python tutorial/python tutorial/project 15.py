# last Exercise
Hours = 35
Rate = 2.75
Pay = Hours * Rate
print ( Pay)